<?php
// NOTE => Field Type

$mod_strings['fieldTypes']['Ampel']='Ampel';
$mod_strings['RANGE_MAX_VALUE']='Range max';
$mod_strings['RANGE_MIN_VALUE']='Range min';

?>
