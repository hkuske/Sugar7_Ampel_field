<?php
$mod_strings['LBL_AMPEL_SCORING']='Scoring';
